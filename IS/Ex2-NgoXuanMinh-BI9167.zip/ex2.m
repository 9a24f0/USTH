%% parameters: (x, e, m) where
%% x is variable
%% e is exponentiation
%% m is modular
modular_exponentiation(5, 1024, 7)